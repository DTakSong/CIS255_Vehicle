import java.util.ArrayList;
import java.util.Scanner;

public static main(String[] args)
{
   String[] store = new string[3];
   string[] store = {data};
   ArrayList<store> vehicles = new ArrayList<store>(); //creates ArrayList to store vehicle data
   vehicle.add("");
}