package application;
import java.io.*;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import java.util.Scanner;
import javafx.scene.control.Button;
import javafx.scene.layout.*;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import java.io.FileWriter;
import java.io.BufferedWriter;
import javafx.scene.layout.VBox;
import javafx.geometry.Insets;


public class CIS255_Vehicle2
{
   String getMake();
   String getType();
   String getModel();
   int getYear();
   String getColor();
   int getDoors();
   String getTransmission();
   String getEngine();
   
}

class reader
{
   Scanner read = ("VehicleStore.java");
   
}



class vehicle
{
   String make = ("make");
   String type = ("type");
   String model = ("model");
   String engine = ("engine");
   int year = ("year");
   String transmission = ("transmission");
   int doors = ("doors");
   String color = ("color");
}

class chevorletCamaro 
{
  
     String make = "Chevorlet";
  
  
     String type = "Coupe";
     
     String  model = "Camaro";

}
  



class camaro extends chevorletCamaro
{
   String color = "Black";
   String engine = "Gasoline";
   int doors = "2";
   String transmission = "RWD";
}

class chevorletCorvette
{
   String make = "Chevorlet";
  
   String type = "Coupe";
  
   String model = "Corvette";
 }
  
  class corvette extends chevorletCorvette
{
   String color = "Black";
   String engine = "Gasoline";
   int doors = "2";
   String transmission = "RWD";
}


class chevorletSonic
{
   String make = "Chevorlet";
  
  String type = "Sedan";
  
  String  model = "Sonic";
}
    
  class sonic extends chevorletSonic
{
   String color = "Black";
   String engine = "Gasoline";
   int doors = "2";
   String transmission = "RWD";
}

  
   class chevorletMalibu
{
   String make = "Chevorlet";
  
  String type = "Sedan";
  
  String  model = "Malibu";
}
  
  class malibu extends chevorletMalibu
{
   String color = "Black";
   String engine = "Gasoline";
   int doors = "2";
   String transmission = "RWD";
}

  
  class chevorletCruze
{
   String make = "Chevorlet";
  
  String type = "Sedan";
  
  String  model = "Cruze";
}
  
  class cruze extends chevorletCruze
{
   String color = "Black";
   String engine = "Gasoline";
   int doors = "2";
   String transmission = "RWD";
}

 class chevorletTahoe
{
   String make = "Chevorlet";
  
  String type = "SUV";
  
  String  model = "Tahoe";
}

 class chevorletEquinox
{
   String make = "Chevorlet";
  
  String type = "SUV";
  
  String  model = "Equinox";
}

 class chevorletBlazer
{
   String make = "Chevorlet";
  
  String type = "SUV";
  
  String  model = "Blazer";
}

class chevorletTrailblazer
{
   String make = "Chevorlet";
  
  String type = "SUV";
  
  String  model = "TrailBlazer";
}

  
   class chevorletSilverado
{
   String make = "Chevorlet";
  
  String type = "truck";
  
  String  model = "Silverado";
 }
  
  class silverado extends chevorletSilverado
{
   String color = "Black";
   String engine = "Gasoline";
   int doors = "2";
   String transmission = "RWD";
}

  
   class chevorletColorado
{
   String make = "Chevorlet";
  
  String type = "truck";
  
  String  model = "Colorado";
}
  
  class colorado extends chevorletColorado
{
   String color = "Black";
   String engine = "Gasoline";
   int doors = "2";
   String transmission = "RWD";
}



    class base extends Application
   {
      public static void end(String[] args)
   {
      launch(args);
   }  
   @override
   
    void start(stage stage) throws exception
   {
      stage.show();
   }
   }

 
    class menuSelect extends Application
    {
       void start()
      {
         Menu top = new Menu("Top");
         Menu l2 = new Menu();
         Menu l3 = new Menu();
         
         
         MenuBar menubar = new MenuBar(menu);
         menubar.getItems().add(top);
         Vbox vbox = new VBox();
      vbox.setPadding(new Insets(15, 12, 12));
      vbox.setSpacing(10);
      vbox.setStyle("-fx-background-color: #336699;");
      Button.buttonSelect = new Button("Select Vehicles");
         buttonSelect.setPrefSize(100, 20);
         
         Button buttonShow = new Button("Show Vehicles");
         buttonShow.setPrefSize(100, 20);
         
         Button buttonExit = new Button("Exit");
         buttonExit.setPrefSize(100, 20);
         
         Button buttonSave = new Button("Save to File");
         buttonSave.setPrefSize(100, 20);
         
         hbox.getChildren().addAll(buttonSelect, buttonShow, buttonSave, buttonExit);
         
         return vbox;
         
         FileWriter write = new FileWriter();
       }
    }
 @Override 
    class borderPane {
      public void pane() {
         BorderPane border = new BorderPane();
         Hbox hbox = addHBox();
         border.setTop(hbox);
         border.setLeft(addVBox());
         addStackPane(hbox);
         border.setCenter(addGridPane);
         border.setRight(addFlowPane);
       }
    }
    @override
     class buttons {  
        
             }
   