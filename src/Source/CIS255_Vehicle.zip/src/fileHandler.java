import java.io.BufferedWriter;
import java.io.FileWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


class fileHandler 
{
   public static void main(String[] args)
   {
   LocalDateTime dateT = LocalDateTime.now();
   DateTimeFormatter dateTimeForm = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
   String dateTime = dateT.format(dateTimeForm);
   try {
      BufferedWriter writer = new BufferedWriter(new FileWriter(Vehicle_Selection_[ISO_LOCAL_DATE_TIME].csv));
      Writer.write("Write");
      Writer.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
      
    }
}